#include <WiFi.h>
#include <WiFiClientSecure.h> // Required for Port 8883 (TLS)
#include <PubSubClient.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHT.h"

// --- Hardware Pins (XIAO ESP32-C3) ---
#define TURBIDITY_PIN D0
#define DHTPIN D1
#define DHTTYPE DHT22   
#define GREEN_LED_PIN D2
#define RED_LED_PIN D3
#define BUZZER_PIN D8

// --- OLED Config ---
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// --- Network & HiveMQ Config ---
const char* ssid = "Wokwi-GUEST";
const char* password = "";
const char* mqtt_server = "ad51ca86227e469982648befb63559fb.s1.eu.hivemq.cloud";
const int mqtt_port = 8883;
const char* mqtt_user = "ABBIE";
const char* mqtt_password = "Abbie0322";

// Topic to send data to Node-RED
const char* mqtt_topic = "seel3742/aqua/telemetry";

// --- Thresholds ---
const int TURBIDITY_THRESHOLD = 2000;  // Simulated threshold (0-4095)
const float TEMP_THRESHOLD = 30.0;     // High temperature threshold in Celsius

WiFiClientSecure espClient; // Secure client for HiveMQ
PubSubClient client(espClient);
DHT dht(DHTPIN, DHTTYPE);

void setup_wifi() {
  delay(10);
  Serial.print("Connecting to WiFi");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected.");
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // Generate a random client ID to avoid collisions
    String clientId = "ESP32_Wokwi_";
    clientId += String(random(0xffff), HEX);
    
    // Connect using Username and Password
    if (client.connect(clientId.c_str(), mqtt_user, mqtt_password)) {
      Serial.println("connected to HiveMQ!");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);

  // IMPORTANT: Skips SSL certificate validation for the simulation
  espClient.setInsecure(); 

  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  dht.begin();
  
  // Initialize I2C with the default XIAO ESP32C3 I2C pins (D4=SDA, D5=SCL)
  Wire.begin(D4, D5);
  
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("SSD1306 allocation failed"));
    for(;;);
  }
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.setCursor(0, 10);
  display.setTextSize(1);
  display.println("Connecting...");
  display.display();

  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) reconnect();
  client.loop();

  // Read sensors
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  int turbidityValue = analogRead(TURBIDITY_PIN);

  // Wait for valid DHT reading
  if (isnan(h) || isnan(t)) return; 

  String statusStr;

  // Process logic and hardware outputs
  display.clearDisplay();
  display.setCursor(0, 0);
  display.setTextSize(1);
  display.print("Temp: "); display.print(t); display.println(" C");
  display.print("Hum:  "); display.print(h); display.println(" %");
  display.print("Turb: "); display.println(turbidityValue);
  display.println("");

  display.setTextSize(2);
  
  // ---> NEW LOGIC HERE <---
  // The '&&' means BOTH must be true to sound the alarm.
  // If you want the alarm to sound if EITHER is bad, change '&&' to '||'
  if (turbidityValue > TURBIDITY_THRESHOLD || t > TEMP_THRESHOLD) {
    statusStr = "Polluted"; // Keeping this as "Polluted" so your Node-RED text turns red
    digitalWrite(RED_LED_PIN, HIGH);
    digitalWrite(GREEN_LED_PIN, LOW);
    tone(BUZZER_PIN, 1000); 
    display.println("WARNING!");
  } else {
    statusStr = "Safe";
    digitalWrite(RED_LED_PIN, LOW);
    digitalWrite(GREEN_LED_PIN, HIGH);
    noTone(BUZZER_PIN); 
    display.println("SAFE");
  }
  display.display();

  // Create JSON Payload
  String payload = "{\"temperature\":";
  payload += t;
  payload += ",\"humidity\":";
  payload += h;
  payload += ",\"turbidity\":";
  payload += turbidityValue;
  payload += ",\"status\":\"";
  payload += statusStr;
  payload += "\"}";

  // Publish to HiveMQ
  client.publish(mqtt_topic, payload.c_str());
  Serial.println("Published: " + payload);
  
  delay(2000);
}